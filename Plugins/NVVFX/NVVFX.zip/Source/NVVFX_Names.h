#pragma once
#include <Nodos/PluginHelpers.hpp>

extern nos::Name NSN_NVVFX_AR;
extern nos::Name NSN_NVVFX_SuperRes;
extern nos::Name NSN_NVVFX_AIGreenScreen;
extern nos::Name NSN_In;
extern nos::Name NSN_UpscaleFactor;
extern nos::Name NSN_ModelsPath;
extern nos::Name NSN_UpscaleStrength;
extern nos::Name NSN_Out;